import urllib.request
import json

response = urllib.request.urlopen('http://localhost:8000/api/articles?limit=2')
data = response.read()
articles = json.loads(data)

print("API 响应:")
print("=" * 80)
for article in articles:
    print(f"\n文章ID: {article['id']}")
    print(f"标题: {article['title']}")
    print(f"公众号: {article.get('channel_name')}")
    print(f"公众号累计阅读量: {article.get('channel_total_read_num')}")
    print(f"文章阅读量: {article.get('read_num')}")
    print(f"所有字段: {list(article.keys())}")
