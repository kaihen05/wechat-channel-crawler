#!/usr/bin/env python
# -*- coding: utf-8 -*-
import httpx

# Test: game category + Beijing University
r = httpx.get('http://localhost:8000/api/channels', params={
    'category': '游戏',
    'university': '北京大学'
})
data = r.json()
print(f'Game + Beijing University channels: {len(data)}')
for c in data:
    print(f'  {c["nickname"]} [{c["category"]}]')

print()

# Test: game category only
r2 = httpx.get('http://localhost:8000/api/channels', params={
    'category': '游戏'
})
data2 = r2.json()
print(f'All game channels: {len(data2)}')
for c in data2:
    print(f'  {c["nickname"]} - {c["university_name"]} [{c["category"]}]')
