import sys
sys.path.insert(0, 'C:/Users/kaiboy/Desktop/wechat-channel-crawler/backend')

from app.database import SessionLocal
from app.models import Article
from sqlalchemy import desc

db = SessionLocal()
try:
    articles = db.query(Article).order_by(desc(Article.create_time)).limit(2).all()

    print("直接从数据库查询结果:")
    print("=" * 80)
    for article in articles:
        print(f"\n文章 ID: {article.id}")
        print(f"标题: {article.title}")
        print(f"Channel ID: {article.channel_id}")
        print(f"Channel 对象: {article.channel}")
        print(f"Channel total_read_num: {article.channel.total_read_num if hasattr(article.channel, 'total_read_num') else '无该属性'}")
finally:
    db.close()
