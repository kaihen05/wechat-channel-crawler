import urllib.request
import json

# 测试测试技术公众号的文章
response = urllib.request.urlopen('http://localhost:8000/api/articles?channel_id=2')
articles = json.loads(response.read())

print("测试技术公众号（ID=2）的文章:")
print("=" * 80)
for article in articles:
    print(f"\n文章ID: {article['id']}")
    print(f"标题: {article['title']}")
    print(f"公众号: {article.get('channel_name')}")
    print(f"公众号累计阅读量: {article.get('channel_total_read_num')}")
    print(f"文章阅读量: {article.get('read_num')}")
    print(f"所有字段: {list(article.keys())}")
