#!/usr/bin/env python
"""测试微信 API 获取文章阅读量"""
from app.services.wechat_crawler import WeChatCrawler
from app.database import SessionLocal
from app.models import Article
from app.config import settings
from datetime import datetime, timedelta

def test_api():
    """测试 API 调用"""
    db = SessionLocal()
    try:
        # 获取几篇有 msgid 的文章
        articles = db.query(Article).filter(
            Article.msgid != "",
            Article.msgid != None
        ).limit(5).all()
        
        print(f"测试 {len(articles)} 篇文章的 API 调用")
        print("=" * 80)
        
        # 创建爬虫实例
        crawler = WeChatCrawler(
            appid=settings.wechat_appid,
            appsecret=settings.wechat_appsecret
        )
        
        # 计算日期范围（今天）
        today = datetime.now()
        begin_date = today.strftime("%Y%m%d")
        end_date = today.strftime("%Y%m%d")
        
        print(f"日期范围: {begin_date} - {end_date}")
        print(f"AppID: {settings.wechat_appid}")
        print("=" * 80)
        
        for article in articles:
            print(f"\n文章: {article.title[:50]}")
            print(f"msgid: {article.msgid}")
            print(f"create_time: {article.create_time}")
            
            # 尝试获取阅读统计
            stats = crawler.get_article_read_stats(
                data_id=article.msgid,
                begin_date=begin_date,
                end_date=end_date
            )
            
            if stats:
                print(f"API 返回结果: {stats}")
                if len(stats) > 0:
                    total_read = sum(item.get("int_page_read_user", 0) for item in stats)
                    print(f"总阅读量: {total_read}")
            else:
                print("API 返回失败")
        
        print("\n" + "=" * 80)
        
    except Exception as e:
        print(f"测试失败: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()

if __name__ == "__main__":
    test_api()
