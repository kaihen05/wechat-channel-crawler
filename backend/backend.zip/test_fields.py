"""测试新增字段"""
from app.database import SessionLocal
from app.models import Article, Channel
from datetime import datetime

db = SessionLocal()

# 测试1: 添加带大学名称的公众号
print("测试1: 添加带大学名称的公众号")
channel = Channel(
    fakeid='test_002',
    nickname='测试技术公众号',
    category='技术',
    university_name='北京大学',
    account_name='testtech',
    is_active=True
)
db.add(channel)
db.commit()
print(f"成功添加: ID={channel.id}, 名称={channel.nickname}, 大学={channel.university_name}")

# 测试2: 添加带浏览量的文章
print("\n测试2: 添加带浏览量的文章")
article = Article(
    channel_id=channel.id,
    title='测试技术文章',
    content_url='https://test.com/article',
    link='https://test.com/link',
    author='技术小编',
    create_time=datetime.now(),
    read_num=67890
)
db.add(article)
db.commit()
print(f"成功添加: ID={article.id}, 标题={article.title}, 浏览量={article.read_num}")

# 测试3: 查询并显示
print("\n测试3: 查询并显示")
channels = db.query(Channel).all()
print(f"\n公众号列表 ({len(channels)}个):")
for c in channels:
    print(f"  {c.id}: {c.nickname} - {c.university_name} - {c.category}")

articles = db.query(Article).all()
print(f"\n文章列表 ({len(articles)}篇):")
for a in articles:
    print(f"  {a.id}: {a.title} - 浏览量:{a.read_num} - 公众号:{a.channel.nickname}")

db.close()
print("\n测试完成!")
