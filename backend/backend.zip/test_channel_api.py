#!/usr/bin/env python
"""
测试特定公众号的文章
"""
import sys
sys.path.insert(0, 'C:/Users/kaiboy/Desktop/wechat-channel-crawler/backend')

from app.database import SessionLocal
from app.models import Article
from sqlalchemy import desc
import json

def test_specific_channel():
    """测试特定公众号的文章"""
    db = SessionLocal()
    try:
        # 获取测试技术公众号（ID=2）的文章
        articles = db.query(Article).filter(Article.channel_id == 2).all()

        # 转换为响应格式（与API完全相同的逻辑）
        result = []
        for article in articles:
            article_dict = {
                "id": article.id,
                "channel_id": article.channel_id,
                "title": article.title,
                "link": article.link,
                "author": article.author or "未知作者",
                "create_time": article.create_time.isoformat() if article.create_time else None,
                "collected_at": article.collected_at.isoformat() if article.collected_at else None,
                "channel_name": article.channel.nickname,
                "account_name": article.channel.account_name or article.channel.nickname,
                "university_name": article.channel.university_name or "",
                "category": article.channel.category or "未分类",
                "read_num": article.read_num or 0,
            }
            # 添加公众号累计阅读量
            if hasattr(article.channel, 'total_read_num') and article.channel.total_read_num is not None:
                article_dict["channel_total_read_num"] = article.channel.total_read_num
            else:
                article_dict["channel_total_read_num"] = 0

            if article.digest:
                article_dict["digest"] = article.digest

            result.append(article_dict)

        print("=" * 80)
        print("测试技术公众号（ID=2）的文章")
        print("=" * 80)
        for i, article in enumerate(result, 1):
            print(f"\n文章 {i}:")
            print(f"  ID: {article['id']}")
            print(f"  标题: {article['title']}")
            print(f"  公众号: {article['channel_name']}")
            print(f"  文章阅读量: {article['read_num']}")
            print(f"  公众号累计阅读量: {article['channel_total_read_num']}")
            print(f"  包含 channel_total_read_num 字段: {'channel_total_read_num' in article}")

        print("\n" + "=" * 80)
        print("这个公众号应该显示绿色的 '公众号阅读: 67890' 标签")
        print("=" * 80)

        return result

    finally:
        db.close()

if __name__ == "__main__":
    test_specific_channel()
