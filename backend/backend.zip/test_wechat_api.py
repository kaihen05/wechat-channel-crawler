"""
测试微信 API 阅读量更新功能
"""
import sys
from datetime import datetime, timedelta
from app.database import SessionLocal
from app.models import Article, Channel
from app.services.wechat_crawler import WeChatCrawler
from app.config import settings
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def test_api_update():
    """测试通过微信 API 更新阅读量"""
    
    # 检查配置
    if not settings.wechat_appid or not settings.wechat_appsecret:
        logger.error("未配置微信 API 凭证！")
        logger.error("请在 backend/.env 或 backend/app/config.py 中设置：")
        logger.error("  WECHAT_APPID=your_appid")
        logger.error("  WECHAT_APPSECRET=your_appsecret")
        return
    
    logger.info(f"使用 AppID: {settings.wechat_appid}")
    
    # 创建爬虫实例
    crawler = WeChatCrawler(
        appid=settings.wechat_appid,
        appsecret=settings.wechat_appsecret
    )
    
    # 测试获取 access token
    logger.info("测试获取 access token...")
    token = crawler.get_access_token()
    if not token:
        logger.error("无法获取 access token，请检查 AppID 和 AppSecret")
        return
    
    logger.info(f"成功获取 access token: {token[:20]}...")
    
    # 查询数据库中的文章
    db = SessionLocal()
    try:
        # 获取最近 7 天的文章
        end_date = datetime.now()
        begin_date = end_date - timedelta(days=7)
        
        articles = db.query(Article).filter(
            Article.create_time >= begin_date,
            Article.create_time <= end_date
        ).limit(5).all()
        
        logger.info(f"找到 {len(articles)} 篇文章进行测试")
        
        if not articles:
            logger.warning("没有找到最近的文章，请先同步一些文章")
            return
        
        # 测试更新第一篇文章
        article = articles[0]
        logger.info(f"测试文章: {article.title[:50]}...")
        logger.info(f"  msgid: {article.msgid}")
        
        if not article.msgid:
            logger.warning("该文章没有 msgid，跳过")
            return
        
        # 转换日期格式
        begin_str = begin_date.strftime("%Y%m%d")
        end_str = end_date.strftime("%Y%m%d")
        
        # 调用 API 获取阅读统计
        logger.info(f"调用微信 API 获取阅读统计: {begin_str} - {end_str}")
        stats = crawler.get_article_read_stats(
            data_id=article.msgid,
            begin_date=begin_str,
            end_date=end_str
        )
        
        if stats:
            logger.info(f"成功获取阅读统计: {len(stats)} 条记录")
            for stat in stats[:3]:  # 只显示前 3 条
                logger.info(f"  日期: {stat.get('ref_date')}, 阅读: {stat.get('int_page_read_user', 0)}, 分享: {stat.get('share_user', 0)}")
        else:
            logger.error("获取阅读统计失败")
            logger.info("可能的原因:")
            logger.info("  1. msgid 不正确或格式错误")
            logger.info("  2. 日期范围超出 API 支持范围")
            logger.info("  3. 文章不属于你管理的公众号")
            logger.info("  4. API 调用次数已达上限")
    
    finally:
        db.close()


def test_user_summary():
    """测试获取用户增减数据"""
    
    if not settings.wechat_appid or not settings.wechat_appsecret:
        logger.error("未配置微信 API 凭证！")
        return
    
    logger.info("测试获取用户增减数据...")
    
    crawler = WeChatCrawler(
        appid=settings.wechat_appid,
        appsecret=settings.wechat_appsecret
    )
    
    # 获取昨天的数据
    yesterday = datetime.now() - timedelta(days=1)
    date_str = yesterday.strftime("%Y%m%d")
    
    logger.info(f"查询日期: {date_str}")
    
    summary = crawler.get_user_summary(date_str, date_str)
    
    if summary:
        logger.info(f"成功获取用户增减数据: {len(summary)} 条记录")
        for item in summary[:5]:
            logger.info(f"  日期: {item.get('ref_date')}, 新增: {item.get('new_user', 0)}, 取消: {item.get('cancel_user', 0)}")
    else:
        logger.error("获取用户增减数据失败")


if __name__ == "__main__":
    print("=" * 60)
    print("微信 API 功能测试")
    print("=" * 60)
    print()
    
    print("测试 1: 获取 access token 并更新文章阅读量")
    test_api_update()
    print()
    
    print("测试 2: 获取用户增减数据")
    test_user_summary()
    print()
    
    print("=" * 60)
    print("测试完成！")
    print("=" * 60)
