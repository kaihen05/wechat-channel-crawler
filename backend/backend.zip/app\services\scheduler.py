from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import httpx
from app.config import settings
from app.database import SessionLocal
from app.models import Channel
import logging

logger = logging.getLogger(__name__)


class SyncScheduler:
    """定时同步任务调度器"""
    
    def __init__(self):
        self.scheduler = AsyncIOScheduler()
        self.api_base_url = f"http://{settings.host}:{settings.port}"
    
    def start(self):
        """启动调度器"""
        # 添加每天定时同步任务
        self.scheduler.add_job(
            self.daily_sync_job,
            CronTrigger(
                hour=settings.daily_schedule_hour,
                minute=settings.daily_schedule_minute
            ),
            id="daily_sync_articles",
            name="每天同步公众号文章",
            replace_existing=True
        )
        
        # 添加每周定时同步任务
        self.scheduler.add_job(
            self.weekly_sync_job,
            CronTrigger(
                day_of_week=settings.weekly_day,
                hour=settings.weekly_hour,
                minute=settings.weekly_minute
            ),
            id="weekly_sync_articles",
            name="每周同步公众号文章",
            replace_existing=True
        )
        
        # 如果启用了每周自动导出，添加导出任务
        if settings.auto_export_weekly:
            self.scheduler.add_job(
                self.weekly_export_job,
                CronTrigger(
                    day_of_week=settings.weekly_day,
                    hour=settings.weekly_hour,
                    minute=settings.weekly_minute,
                ),
            )
        
        self.scheduler.start()
        logger.info(f"每天定时任务已启动，每天 {settings.daily_schedule_hour:02d}:{settings.daily_schedule_minute:02d} 执行")
        logger.info(f"每周定时任务已启动，每周{['一','二','三','四','五','六','日'][settings.weekly_day]} {settings.weekly_hour:02d}:{settings.weekly_minute:02d} 执行")
        if settings.auto_export_weekly:
            logger.info(f"每周自动导出已启用")
    
    def stop(self):
        """停止调度器"""
        self.scheduler.shutdown()
        logger.info("定时任务已停止")
    
    async def daily_sync_job(self):
        """每天同步任务"""
        logger.info("开始执行每天定时同步任务...")
        
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(f"{self.api_base_url}/api/articles/sync")
                
                if response.status_code == 200:
                    result = response.json()
                    logger.info(f"每天同步完成: {result['message']}")
                else:
                    logger.error(f"每天同步失败: {response.status_code}")
                    
        except Exception as e:
            logger.error(f"每天同步任务异常: {e}")
    
    async def weekly_sync_job(self):
        """每周同步任务"""
        logger.info("开始执行每周定时同步任务...")
        
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(f"{self.api_base_url}/api/articles/sync")
                
                if response.status_code == 200:
                    result = response.json()
                    logger.info(f"每周同步完成: {result['message']}")
                else:
                    logger.error(f"每周同步失败: {response.status_code}")
                    
        except Exception as e:
            logger.error(f"每周同步任务异常: {e}")
    
    async def weekly_export_job(self):
        """每周导出Excel任务"""
        logger.info("开始执行每周Excel导出任务...")
        
        try:
            # 等待同步完成后再导出
            await asyncio.sleep(60)  # 等待60秒
            
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.get(
                    f"{self.api_base_url}/api/export/excel",
                    params={"auto": "true"}
                )
                
                if response.status_code == 200:
                    logger.info(f"每周Excel导出完成")
                else:
                    logger.error(f"每周Excel导出失败: {response.status_code}")
                    
        except Exception as e:
            logger.error(f"每周Excel导出任务异常: {e}")


# 导入asyncio
import asyncio


# 全局调度器实例
scheduler = SyncScheduler()
