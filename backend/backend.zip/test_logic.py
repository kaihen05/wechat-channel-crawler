import sys
sys.path.insert(0, 'C:/Users/kaiboy/Desktop/wechat-channel-crawler/backend')

from app.database import SessionLocal
from app.models import Article
from sqlalchemy import desc
import json

db = SessionLocal()
try:
    # 执行与API相同的逻辑
    articles = db.query(Article).order_by(desc(Article.create_time)).limit(2).all()

    # 转换为响应格式
    result = []
    for article in articles:
        article_dict = {
            "id": article.id,
            "channel_id": article.channel_id,
            "title": article.title,
            "link": article.link,
            "author": article.author or "未知作者",
            "create_time": article.create_time.isoformat() if article.create_time else None,
            "collected_at": article.collected_at.isoformat() if article.collected_at else None,
            "channel_name": article.channel.nickname,
            "account_name": article.channel.account_name or article.channel.nickname,
            "university_name": article.channel.university_name or "",
            "category": article.channel.category or "未分类",
            "read_num": article.read_num or 0,
        }
        # 添加公众号累计阅读量
        if hasattr(article.channel, 'total_read_num') and article.channel.total_read_num is not None:
            article_dict["channel_total_read_num"] = article.channel.total_read_num
        else:
            article_dict["channel_total_read_num"] = 0

        if article.digest:
            article_dict["digest"] = article.digest

        result.append(article_dict)

    print("直接执行逻辑的结果:")
    print("=" * 80)
    for article in result:
        print(f"\n文章ID: {article['id']}")
        print(f"标题: {article['title']}")
        print(f"公众号: {article.get('channel_name')}")
        print(f"公众号累计阅读量: {article.get('channel_total_read_num')}")
        print(f"文章阅读量: {article.get('read_num')}")
        print(f"所有字段: {list(article.keys())}")

finally:
    db.close()
